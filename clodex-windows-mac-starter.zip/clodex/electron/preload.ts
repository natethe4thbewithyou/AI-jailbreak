import { contextBridge, ipcRenderer } from "electron";
contextBridge.exposeInMainWorld("clodex", {
  loadState: () => ipcRenderer.invoke("state:load"),
  saveState: (value: unknown) => ipcRenderer.invoke("state:save", value),
  detectAgents: () => ipcRenderer.invoke("agent:detect"),
  openProject: () => ipcRenderer.invoke("project:open"),
  listProject: (directory: string) => ipcRenderer.invoke("project:list", directory),
  readFile: (root: string, relativePath: string) => ipcRenderer.invoke("file:read", root, relativePath),
  writeFile: (root: string, relativePath: string, contents: string) => ipcRenderer.invoke("file:write", root, relativePath, contents),
  gitRun: (root: string, args: string[]) => ipcRenderer.invoke("git:run", root, args),
  runAgent: (input: { agent: "codex" | "claude"; cwd: string; prompt: string; permission: string }) => ipcRenderer.invoke("agent:run", input),
  startTerminal: (cwd: string) => ipcRenderer.invoke("terminal:start", cwd),
  terminalInput: (id: string, data: string) => ipcRenderer.send("terminal:input", id, data),
  terminalResize: (id: string, cols: number, rows: number) => ipcRenderer.send("terminal:resize", id, cols, rows),
  killTerminal: (id: string) => ipcRenderer.send("terminal:kill", id),
  onAgentOutput: (callback: (data: { stream: string; text: string }) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: { stream: string; text: string }) => callback(data);
    ipcRenderer.on("agent:output", listener); return () => ipcRenderer.removeListener("agent:output", listener);
  },
  onTerminalData: (callback: (data: { id: string; data: string }) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: { id: string; data: string }) => callback(data);
    ipcRenderer.on("terminal:data", listener); return () => ipcRenderer.removeListener("terminal:data", listener);
  },
  onTerminalExit: (callback: (data: { id: string; exitCode: number }) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: { id: string; exitCode: number }) => callback(data);
    ipcRenderer.on("terminal:exit", listener); return () => ipcRenderer.removeListener("terminal:exit", listener);
  }
});
