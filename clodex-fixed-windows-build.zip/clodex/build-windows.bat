@echo off
setlocal
cd /d "%~dp0"
if not exist package.json (
  echo ERROR: package.json not found. Keep this script in the Clodex project folder.
  pause
  exit /b 1
)
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or is not on PATH.
  pause
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: npm is not available.
  pause
  exit /b 1
)
echo === Installing dependencies ===
call npm install
if errorlevel 1 goto failed
echo === Building Clodex ===
call npm run build
if errorlevel 1 goto failed
echo === Packaging Windows application folder ===
call npx electron-builder --win --x64 --dir
if errorlevel 1 goto failed
if not exist "release\win-unpacked\Clodex.exe" (
  echo ERROR: Packaging finished but Clodex.exe was not found.
  goto failed
)
echo.
echo SUCCESS! Open release\win-unpacked\Clodex.exe
explorer "release\win-unpacked"
pause
exit /b 0
:failed
echo.
echo BUILD FAILED. Copy the error text above so the issue can be fixed.
pause
exit /b 1
