import { app, BrowserWindow, dialog, ipcMain } from "electron";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import fs from "node:fs/promises";
import * as pty from "node-pty";
import crossSpawn from "cross-spawn";

const execFileAsync = promisify(execFile);
let mainWindow: BrowserWindow | null = null;
const terminals = new Map<string, pty.IPty>();
const sessionsFile = () => path.join(app.getPath("userData"), "workspace-state.json");

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500, height: 960, minWidth: 1050, minHeight: 700,
    backgroundColor: "#101114",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  if (!app.isPackaged) mainWindow.loadURL("http://localhost:5173");
  else mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
}
app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on("before-quit", () => { for (const terminal of terminals.values()) terminal.kill(); });
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });

const agents = {
  codex: { command: process.platform === "win32" ? "codex.cmd" : "codex" },
  claude: { command: process.platform === "win32" ? "claude.cmd" : "claude" }
} as const;

function safePath(projectRoot: string, relativePath: string) {
  const root = path.resolve(projectRoot);
  const target = path.resolve(root, relativePath);
  if (target !== root && !target.startsWith(root + path.sep)) throw new Error("Path escapes the selected project.");
  return target;
}
function send(channel: string, payload: unknown) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}
async function readState() {
  try { return JSON.parse(await fs.readFile(sessionsFile(), "utf8")); }
  catch { return { recentProjects: [], conversations: [] }; }
}
async function writeState(value: unknown) {
  await fs.mkdir(path.dirname(sessionsFile()), { recursive: true });
  await fs.writeFile(sessionsFile(), JSON.stringify(value, null, 2), "utf8");
}

ipcMain.handle("state:load", readState);
ipcMain.handle("state:save", async (_event, value) => { await writeState(value); return true; });

ipcMain.handle("agent:detect", async () => {
  const result: Record<string, { installed: boolean; version?: string; error?: string }> = {};
  for (const [name, config] of Object.entries(agents)) {
    try {
      const version = await new Promise<string>((resolve, reject) => {
        const child = crossSpawn(config.command, ["--version"], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
        let output = "";
        child.stdout?.on("data", (chunk: Buffer) => { output += chunk.toString("utf8"); });
        child.stderr?.on("data", (chunk: Buffer) => { output += chunk.toString("utf8"); });
        const timer = setTimeout(() => child.kill(), 8000);
        child.on("error", error => { clearTimeout(timer); reject(error); });
        child.on("close", code => {
          clearTimeout(timer);
          if (code === 0) resolve(output.trim().split(/\r?\n/)[0] || "Detected");
          else reject(new Error(`CLI exited with status ${code}`));
        });
      });
      result[name] = { installed: true, version };
    } catch (error) { result[name] = { installed: false, error: error instanceof Error ? error.message : String(error) }; }
  }
  return result;
});

ipcMain.handle("project:open", async () => {
  const picked = await dialog.showOpenDialog({ properties: ["openDirectory"] });
  return picked.canceled ? null : picked.filePaths[0] || null;
});
ipcMain.handle("project:list", async (_event, directory: string) => {
  const root = path.resolve(directory);
  const walk = async (dir: string, prefix = ""): Promise<Array<{ name: string; path: string; directory: boolean }>> => {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const result: Array<{ name: string; path: string; directory: boolean }> = [];
    for (const entry of entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name))) {
      if (entry.name.startsWith(".") || ["node_modules", "dist", "build", "release", ".git"].includes(entry.name)) continue;
      const relative = path.posix.join(prefix, entry.name);
      result.push({ name: entry.name, path: relative, directory: entry.isDirectory() });
      if (entry.isDirectory()) result.push(...await walk(path.join(dir, entry.name), relative));
    }
    return result;
  };
  return walk(root);
});
ipcMain.handle("file:read", async (_event, projectRoot: string, relativePath: string) => {
  const target = safePath(projectRoot, relativePath);
  const stat = await fs.stat(target);
  if (!stat.isFile() || stat.size > 5_000_000) throw new Error("File is not readable or exceeds 5 MB.");
  return fs.readFile(target, "utf8");
});
ipcMain.handle("file:write", async (_event, projectRoot: string, relativePath: string, contents: string) => {
  const target = safePath(projectRoot, relativePath);
  const parent = path.dirname(target);
  await fs.mkdir(parent, { recursive: true });
  await fs.writeFile(target, contents, "utf8");
  return true;
});

ipcMain.handle("terminal:start", async (_event, projectRoot: string) => {
  const cwd = path.resolve(projectRoot);
  if (!(await fs.stat(cwd)).isDirectory()) throw new Error("Terminal working directory is invalid.");
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const shell = process.platform === "win32" ? "powershell.exe" : (process.env.SHELL || "/bin/zsh");
  const args = process.platform === "win32" ? ["-NoLogo"] : ["-l"];
  const terminal = pty.spawn(shell, args, {
    name: "xterm-256color", cols: 100, rows: 28, cwd,
    env: { ...process.env, TERM: "xterm-256color" } as Record<string, string>
  });
  terminals.set(id, terminal);
  terminal.onData(data => send("terminal:data", { id, data }));
  terminal.onExit(({ exitCode }) => { terminals.delete(id); send("terminal:exit", { id, exitCode }); });
  return id;
});
ipcMain.on("terminal:input", (_event, id: string, data: string) => terminals.get(id)?.write(data));
ipcMain.on("terminal:resize", (_event, id: string, cols: number, rows: number) => {
  const terminal = terminals.get(id);
  if (terminal && cols > 0 && rows > 0) terminal.resize(Math.min(cols, 300), Math.min(rows, 100));
});
ipcMain.on("terminal:kill", (_event, id: string) => { terminals.get(id)?.kill(); terminals.delete(id); });

ipcMain.handle("git:run", async (_event, projectRoot: string, args: string[]) => {
  const cwd = path.resolve(projectRoot);
  const allowed = new Set(["status", "branch", "log", "diff", "rev-parse"]);
  if (!args.length || !allowed.has(args[0])) throw new Error("Unsupported Git operation.");
  const { stdout, stderr } = await execFileAsync("git", args, { cwd, windowsHide: true, timeout: 15000, maxBuffer: 2 * 1024 * 1024 });
  return { stdout, stderr };
});

ipcMain.handle("agent:run", async (event, input: {
  agent: "codex" | "claude"; cwd: string; prompt: string; permission: string
}) => {
  if (!["codex", "claude"].includes(input.agent)) throw new Error("Unknown agent.");
  const cwd = path.resolve(input.cwd);
  if (!(await fs.stat(cwd)).isDirectory()) throw new Error("Project directory does not exist.");
  if (!input.prompt.trim() || input.prompt.length > 20000) throw new Error("Prompt must be 1–20,000 characters.");

  let args: string[];
  if (input.agent === "codex") {
    const sandbox = input.permission === "read-only" ? "read-only" : "workspace-write";
    args = ["exec", "--color", "never", "--sandbox", sandbox, input.prompt];
  } else {
    const mode = input.permission === "read-only" ? "plan" : "acceptEdits";
    args = ["-p", "--permission-mode", mode, input.prompt];
  }
  const child = crossSpawn(agents[input.agent].command, args, {
    cwd, windowsHide: true, env: { ...process.env, FORCE_COLOR: "0" }, stdio: ["ignore", "pipe", "pipe"]
  }) as import("node:child_process").ChildProcess;
  child.stdout?.on("data", (chunk: Buffer) => send("agent:output", { stream: "stdout", text: chunk.toString("utf8") }));
  child.stderr?.on("data", (chunk: Buffer) => send("agent:output", { stream: "stderr", text: chunk.toString("utf8") }));
  return await new Promise<{ code: number | null; error?: string }>(resolve => {
    child.on("error", error => resolve({ code: null, error: error.message }));
    child.on("close", code => resolve({ code }));
  });
});
