# Clodex 0.2.0

Cross-platform Electron desktop workspace for locally installed OpenAI Codex CLI and Anthropic Claude Code CLI.

## Included in 0.2.0

- Editable Monaco editor with file saving
- Embedded interactive terminal using node-pty and xterm
- Multiple saved conversations
- Agent permission selector (read-only/plan or workspace edits)
- Git branch and working-tree status
- Persistent recent project and conversation state
- Codex and Claude Code local CLI detection and launch

## Requirements

- Node.js 20+
- npm
- Git (for Git integration)
- OpenAI Codex CLI installed and authenticated
- Claude Code CLI installed and authenticated

Install and authenticate each CLI using its vendor's current official instructions. Clodex does not bundle either agent or bypass their account/subscription requirements.

## Run

```bash
npm install
npm run dev
```

## Package

Build on the target operating system:

```bash
npm run dist:win
npm run dist:mac
```

The first command produces Windows NSIS/ZIP artifacts; the second produces macOS DMG/ZIP artifacts. Native dependencies such as node-pty must be built for the target Electron version. If native module loading fails, run the project’s dependency rebuild workflow for Electron before packaging.

For public macOS distribution, configure Developer ID signing and notarization. Windows code signing is recommended.

## Permission behavior

The read-only option maps to Codex `--sandbox read-only` and Claude Code `--permission-mode plan`. Workspace edits maps to Codex `--sandbox workspace-write --ask-for-approval on-request` and Claude Code `--permission-mode acceptEdits`.

The agents still apply their own policies, permission prompts, and tool restrictions. Do not treat this UI selector as a replacement for vendor-side permission controls.

## Current limitations

- Conversation history is stored locally as text; resuming a prior native CLI session/thread is not yet wired up.
- The Git panel currently displays branch and working-tree status. It does not yet stage, commit, push, or resolve conflicts.
- The explorer excludes hidden folders, `.git`, `node_modules`, build, dist, and release folders.
- The file preview/save path is intended for text files. Large files are limited to 5 MB.
- Terminal sessions are local interactive PTYs. Closing the app terminates active terminal processes.
- This is an MVP starter; build and test on Windows and macOS before relying on it for important work.

## Security

Agents and terminals can execute commands and modify files in the selected project. Only open projects you trust. Permission settings should be configured conservatively in each CLI. The Electron renderer is sandboxed and privileged operations go through a narrow preload bridge.

## Windows one-click builds

Extract the project and double-click **build-windows.bat**. This installs dependencies, compiles the project, and creates the Windows app folder at `release\win-unpacked\` (containing `Clodex.exe`). Run `build-installer.bat` to generate an NSIS installer. Do not compile the Inno script until the Windows application actually exists.

The local CLI applications still need to be installed and authenticated separately.
