@echo off
setlocal
cd /d "%~dp0"
call build-windows.bat
if errorlevel 1 exit /b 1
echo === Packaging Windows installer ===
call npx electron-builder --win --x64 --nsis
if errorlevel 1 (
  echo Installer build failed.
  pause
  exit /b 1
)
explorer "release"
pause
