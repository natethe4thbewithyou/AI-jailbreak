import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Editor from "@monaco-editor/react";
import { Terminal as XTerminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { Bot, FolderOpen, Code2, Terminal as TerminalIcon, Send, RefreshCw, FileCode2, Sparkles, Save, Plus, GitBranch, Shield, MessageSquare, ChevronDown } from "lucide-react";

type Agent = "codex" | "claude";
type FileEntry = { name: string; path: string; directory: boolean };
type Message = { role: "user" | "assistant"; text: string };
type Conversation = { id: string; title: string; agent: Agent; messages: Message[]; updatedAt: number };
type State = { recentProjects: string[]; conversations: Conversation[]; activeConversationId?: string };

const makeConversation = (agent: Agent = "codex"): Conversation => ({
  id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  title: "New conversation", agent, messages: [], updatedAt: Date.now()
});

export default function App() {
  const [agent, setAgent] = useState<Agent>("codex");
  const [hydrated, setHydrated] = useState(false);
  const [project, setProject] = useState("");
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [activeFile, setActiveFile] = useState("");
  const [fileText, setFileText] = useState("// Open a project and select a file to begin.");
  const [savedText, setSavedText] = useState(fileText);
  const [prompt, setPrompt] = useState("");
  const [output, setOutput] = useState("");
  const [busy, setBusy] = useState(false);
  const [permission, setPermission] = useState("workspace-write");
  const [detection, setDetection] = useState<Record<string, { installed: boolean; version?: string }>>({});
  const [status, setStatus] = useState("Ready");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState("");
  const [gitStatus, setGitStatus] = useState("Git status not loaded");
  const [gitBranch, setGitBranch] = useState("");
  const [terminalId, setTerminalId] = useState("");
  const [showGit, setShowGit] = useState(false);
  const [showTerminal, setShowTerminal] = useState(true);
  const terminalHost = useRef<HTMLDivElement>(null);
  const terminalRef = useRef<XTerminal | null>(null);
  const fitRef = useRef<FitAddon | null>(null);

  const activeConversation = conversations.find(c => c.id === activeConversationId);
  const refreshAgents = useCallback(async () => {
    try { setDetection(await window.clodex.detectAgents()); }
    catch { setStatus("Could not detect local agent CLIs."); }
  }, []);

  useEffect(() => {
    void (async () => {
      const state = await window.clodex.loadState();
      setConversations(state.conversations || []);
      setActiveConversationId(state.activeConversationId || state.conversations?.[0]?.id || "");
      const recent = state.recentProjects || [];
      if (recent[0]) {
        setProject(recent[0]);
        try {
          setEntries(await window.clodex.listProject(recent[0]));
          setTerminalId(await window.clodex.startTerminal(recent[0]));
        } catch { /* moved project */ }
      }
      setHydrated(true);
    })();
    void refreshAgents();
  }, [refreshAgents]);

  useEffect(() => {
    const state: State = { recentProjects: project ? [project] : [], conversations, activeConversationId };
    if (hydrated) void window.clodex.saveState(state);
  }, [hydrated, project, conversations, activeConversationId]);

  useEffect(() => {
    const offAgent = window.clodex.onAgentOutput(({ stream, text }) => {
      const formatted = stream === "stderr" ? `\n[stderr] ${text}` : text;
      setOutput(old => old + formatted);
      setConversations(old => old.map(c => c.id === activeConversationId
        ? { ...c, messages: c.messages.length && c.messages[c.messages.length - 1].role === "assistant"
          ? [...c.messages.slice(0, -1), { role: "assistant", text: c.messages[c.messages.length - 1].text + formatted }]
          : [...c.messages, { role: "assistant", text: formatted }], updatedAt: Date.now() }
        : c));
    });
    const offTerm = window.clodex.onTerminalData(({ id, data }) => {
      if (id === terminalId) terminalRef.current?.write(data);
    });
    return () => { offAgent(); offTerm(); };
  }, [activeConversationId, terminalId]);

  useEffect(() => {
    if (!terminalHost.current || !showTerminal || !terminalId) return;
    const terminal = new XTerminal({ cursorBlink: true, fontFamily: "DM Mono, monospace", fontSize: 12, theme: { background: "#101114", foreground: "#d7dbe3", cursor: "#d8f36a" } });
    const fit = new FitAddon();
    terminal.loadAddon(fit); terminal.open(terminalHost.current); fit.fit();
    terminal.onData(data => window.clodex.terminalInput(terminalId, data));
    terminalRef.current = terminal; fitRef.current = fit;
    window.clodex.terminalResize(terminalId, terminal.cols, terminal.rows);
    const observer = new ResizeObserver(() => { fit.fit(); window.clodex.terminalResize(terminalId, terminal.cols, terminal.rows); });
    observer.observe(terminalHost.current);
    return () => { observer.disconnect(); terminal.dispose(); terminalRef.current = null; };
  }, [terminalId, showTerminal]);

  const openProject = async () => {
    const selected = await window.clodex.openProject();
    if (!selected) return;
    if (terminalId) window.clodex.killTerminal(terminalId);
    setProject(selected); setActiveFile(""); setFileText(""); setSavedText("");
    try {
      setEntries(await window.clodex.listProject(selected));
      const id = await window.clodex.startTerminal(selected);
      setTerminalId(id); setStatus("Project opened");
      await refreshGit(selected);
    } catch (e) { setStatus(String(e)); }
  };

  const refreshGit = async (cwd = project) => {
    if (!cwd) return;
    try {
      const [statusResult, branchResult] = await Promise.all([
        window.clodex.gitRun(cwd, ["status", "--short", "--branch"]),
        window.clodex.gitRun(cwd, ["branch", "--show-current"])
      ]);
      setGitStatus(statusResult.stdout || "Working tree clean");
      setGitBranch(branchResult.stdout.trim() || "detached");
    } catch { setGitStatus("Not a Git repository or Git unavailable"); setGitBranch(""); }
  };

  const openFile = async (entry: FileEntry) => {
    if (entry.directory || !project) return;
    try {
      const text = await window.clodex.readFile(project, entry.path);
      setActiveFile(entry.path); setFileText(text); setSavedText(text);
    } catch (e) { setStatus(String(e)); }
  };
  const saveFile = async () => {
    if (!project || !activeFile) return;
    try {
      await window.clodex.writeFile(project, activeFile, fileText);
      setSavedText(fileText); setStatus(`Saved ${activeFile}`);
      setEntries(await window.clodex.listProject(project));
    } catch (e) { setStatus(String(e)); }
  };
  const createConversation = (nextAgent: Agent = agent) => {
    const c = makeConversation(nextAgent);
    setConversations(old => [c, ...old]); setActiveConversationId(c.id); setAgent(nextAgent); setOutput("");
  };
  const selectConversation = (c: Conversation) => {
    setActiveConversationId(c.id); setAgent(c.agent);
    setOutput(c.messages.filter(m => m.role === "assistant").map(m => m.text).join("\n"));
  };
  const runAgent = async () => {
    if (!project) { setStatus("Open a project first."); return; }
    if (!detection[agent]?.installed) { setStatus(`${agent} CLI not detected. Install and authenticate it first.`); return; }
    if (!prompt.trim()) return;
    let conversation = activeConversation;
    if (!conversation) { conversation = makeConversation(agent); setConversations(old => [conversation!, ...old]); setActiveConversationId(conversation.id); }
    const request = prompt.trim();
    setPrompt(""); setBusy(true); setOutput(""); setStatus(`Running ${agent}…`);
    setConversations(old => old.map(c => c.id === conversation!.id ? {
      ...c, title: c.title === "New conversation" ? request.slice(0, 42) : c.title,
      agent, messages: [...c.messages, { role: "user", text: request }, { role: "assistant", text: "" }], updatedAt: Date.now()
    } : c));
    try {
      const result = await window.clodex.runAgent({ agent, cwd: project, prompt: request, permission });
      setStatus(result.error || `Finished (exit code ${result.code ?? "unknown"})`);
    } catch (e) { setStatus(String(e)); }
    finally { setBusy(false); }
  };

  const language = useMemo(() => {
    const ext = activeFile.split(".").pop()?.toLowerCase();
    return ({ ts: "typescript", tsx: "typescript", js: "javascript", jsx: "javascript", py: "python", json: "json", md: "markdown", html: "html", css: "css", yml: "yaml", yaml: "yaml", sh: "shell", go: "go", rs: "rust" } as Record<string, string>)[ext || ""] || "plaintext";
  }, [activeFile]);

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Code2 size={19}/></div><span>CLODEX</span><span className="beta">0.2.0</span></div>
      <div className="project-label">{project || "No project opened"}</div>
      <div className="top-actions"><button className="secondary" onClick={openProject}><FolderOpen size={15}/> Open project</button><button className="icon-button" title="Refresh agents" onClick={refreshAgents}><RefreshCw size={16}/></button></div>
    </header>
    <div className="workspace">
      <aside className="sidebar">
        <div className="side-heading">WORKSPACE</div>
        <div className="tree-title"><FileCode2 size={15}/><span>EXPLORER</span></div>
        {!project && <p className="muted small pad">Open a folder to see its files.</p>}
        {entries.map(entry => <button className={`file-row depth-${Math.min(entry.path.split("/").length, 4)} ${activeFile === entry.path ? "selected" : ""}`} key={entry.path} onClick={() => void openFile(entry)}>{entry.directory ? "▸" : "·"} {entry.name}</button>)}
        <div className="side-section"><div className="section-title"><MessageSquare size={13}/> CONVERSATIONS <button onClick={() => createConversation()} title="New conversation"><Plus size={13}/></button></div>
          {conversations.map(c => <button key={c.id} className={`conversation ${activeConversationId === c.id ? "selected" : ""}`} onClick={() => selectConversation(c)}><span className="agent-dot">{c.agent === "codex" ? "C" : "A"}</span><span>{c.title}</span></button>)}
        </div>
        <div className="side-bottom"><div className="side-heading">LOCAL AGENTS</div>
          <AgentStatus name="OpenAI Codex" installed={!!detection.codex?.installed} version={detection.codex?.version}/>
          <AgentStatus name="Claude Code" installed={!!detection.claude?.installed} version={detection.claude?.version}/>
          <div className="git-block"><button className="section-title git-toggle" onClick={() => setShowGit(!showGit)}><GitBranch size={13}/> GIT <ChevronDown size={12}/></button>
            {showGit && <><div className="git-branch">{gitBranch || "No branch"}</div><pre className="git-status">{gitStatus}</pre><button className="tiny-button" onClick={() => void refreshGit()}>Refresh status</button></>}
          </div>
        </div>
      </aside>
      <main className="main-area">
        <div className="editor-tabs"><span className="tab active"><FileCode2 size={14}/>{activeFile || "Welcome"}{activeFile && fileText !== savedText ? " •" : ""}</span><div className="editor-actions"><span className="editor-hint">LOCAL WORKSPACE</span>{activeFile && <button className="tiny-button" disabled={fileText === savedText} onClick={() => void saveFile()}><Save size={12}/> Save</button>}</div></div>
        <div className="editor"><Editor height="100%" theme="vs-dark" language={language} value={fileText} onChange={value => setFileText(value ?? "")} options={{readOnly: !activeFile, minimap: {enabled: false}, fontSize: 13, padding: {top: 18}, scrollBeyondLastLine: false, automaticLayout: true}}/></div>
        <section className="agent-panel">
          <div className="panel-header"><div className="panel-title"><Sparkles size={16}/> AI CODING AGENT</div><div className="panel-controls">
            <div className="agent-switch"><button className={agent === "codex" ? "chosen" : ""} onClick={() => { setAgent("codex"); if (activeConversation) setConversations(old => old.map(c => c.id === activeConversationId ? {...c, agent:"codex"} : c)); }}><Bot size={14}/> Codex</button><button className={agent === "claude" ? "chosen" : ""} onClick={() => { setAgent("claude"); if (activeConversation) setConversations(old => old.map(c => c.id === activeConversationId ? {...c, agent:"claude"} : c)); }}><Bot size={14}/> Claude Code</button></div>
            <label className="permission"><Shield size={12}/><select value={permission} onChange={e => setPermission(e.target.value)}><option value="read-only">Read-only / Plan</option><option value="workspace-write">Workspace edits</option></select></label>
            <button className="tiny-button" onClick={() => createConversation(agent)}><Plus size={12}/> New chat</button>
          </div></div>
          <div className="output" aria-live="polite">{activeConversation?.messages.length ? activeConversation.messages.map((m, i) => <div className={`message ${m.role}`} key={`${activeConversation.id}-${i}`}><b>{m.role === "user" ? "YOU" : activeConversation.agent.toUpperCase()}</b><pre>{m.text || (busy ? "Working…" : "")}</pre></div>) : output || <div className="empty-output"><Sparkles size={19}/><span>Ask {agent === "codex" ? "Codex" : "Claude Code"} to work on this project.</span><small>Each conversation is saved locally.</small></div>}</div>
          <div className="composer"><textarea value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) void runAgent(); }} placeholder={`Message ${agent === "codex" ? "OpenAI Codex" : "Claude Code"}…`} rows={2}/><button className="send" disabled={busy || !prompt.trim()} onClick={() => void runAgent()}>{busy ? <span className="spinner"/> : <Send size={16}/>}</button></div>
          <div className="panel-footer"><span><TerminalIcon size={12}/> Local CLI · {permission === "read-only" ? "read-only" : "workspace edits"}</span><span>{status}</span><span>Ctrl/⌘ + Enter to send</span></div>
        </section>
        <section className={`terminal-panel ${showTerminal ? "" : "collapsed"}`}>
          <div className="terminal-head"><button onClick={() => setShowTerminal(!showTerminal)}><TerminalIcon size={13}/> TERMINAL <ChevronDown size={12}/></button><span>{project ? "Project shell" : "Open a project to start terminal"}</span><button className="tiny-button" onClick={async () => { if (project) { if (terminalId) window.clodex.killTerminal(terminalId); setTerminalId(await window.clodex.startTerminal(project)); } }}>New terminal</button></div>
          {showTerminal && <div className="terminal-host" ref={terminalHost}/>}
        </section>
      </main>
    </div>
  </div>;
}

function AgentStatus({ name, installed, version }: { name: string; installed: boolean; version?: string }) {
  return <div className="agent-status"><span className={`dot ${installed ? "online" : ""}`}/><div><div>{name}</div><small>{installed ? version || "Detected" : "Not detected"}</small></div></div>;
}
